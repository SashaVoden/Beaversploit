def xor_encrypt(data, key)
  encrypted = data.bytes.map.with_index { |byte, i| byte ^ key[i % key.length].ord }
  encrypted.pack("C*")
end

if __FILE__ == $0
  if ARGV.length < 2
    print "[!] Usage: xor_encoder <payload_file> <key>"
    exit
  end

  payload_file = ARGV[0]
  key = ARGV[1]

  data = File.read(payload_file)
  encoded = xor_encrypt(data, key)
  
  File.open("#{payload_file}.xor", "wb") { |f| f.write(encoded) }
  print "[*] Payload encoded successfully: #{payload_file}.xor"
end