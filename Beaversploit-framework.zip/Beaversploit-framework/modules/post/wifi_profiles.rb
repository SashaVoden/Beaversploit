def get_wifi_passwords(target)
  print "[*] Extracting Wi-Fi profiles from #{target}..."
  if Gem.win_platform?
    system("netsh wlan show profiles")
    system("netsh wlan show profile name=* key=clear")  
  else
    print "[!] This module only works on Windows!"
  end
end

if __FILE__ == $0
  target = ARGV[0] || "localhost"
  get_wifi_passwords(target)
end