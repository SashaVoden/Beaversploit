def get_clipboard
  print "[*] Extracting clipboard data..."
  if Gem.win_platform?
    system('powershell Get-Clipboard')
  else
    print "[!] This module only works on Windows!"
  end
end

get_clipboard if __FILE__ == $0