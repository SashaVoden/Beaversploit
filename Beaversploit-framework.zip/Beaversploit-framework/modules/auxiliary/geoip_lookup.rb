require 'resolv'
require 'net/http'
require 'json'

def execute()
  if ARGV.empty?
    print "[!] Usage: geoip_lookup <IP or domain>"
    return
  end

  input = ARGV[0]

  # Если введен домен, преобразуем его в IP
  begin
    ip = Resolv.getaddress(input)
  rescue Resolv::ResolvError
    print "[-] Invalid domain or IP."
    return
  end

  uri = URI("http://ipinfo.io/#{ip}/json")
  response = Net::HTTP.get(uri)
  
  begin
    data = JSON.parse(response)
    city = data["city"] || "Unknown"
    country = data["country"] || "Unknown"

    print "[+] IP Address: #{ip}"
    print "[+] City: #{city}"
    print "[+] Country: #{country}"
  rescue JSON::ParserError
    print "[-] Failed to parse response."
  end
end

execute()