require 'resolv'

def execute()
  if ARGV.empty?
    puts "[!] Usage: dns_lookup <domain>"
    return
  end

  domain = ARGV[0]
  print "[*] Resolving DNS for #{domain}..."

  begin
    ip = Resolv.getaddress(domain)
    print "[+] IP Address: #{ip}"
  rescue Resolv::ResolvError
    print "[-] No DNS record found for #{domain}"
  end
end

execute()