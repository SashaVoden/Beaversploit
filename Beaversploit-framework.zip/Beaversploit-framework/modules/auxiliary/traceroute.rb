def execute()
  if ARGV.empty?
    puts "[!] Usage: traceroute <domain>"
    return
  end

  domain = ARGV[0]
  print "[*] Running traceroute for #{domain}... "
  $stdout.flush  # Убедиться, что строка выведена до запуска system()

  if Gem.win_platform?
    system("tracert #{domain}")  # Windows
  else
    system("traceroute #{domain}")  # Linux/macOS
  end
end

execute()