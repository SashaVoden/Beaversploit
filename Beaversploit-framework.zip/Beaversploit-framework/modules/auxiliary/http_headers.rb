require 'net/http'

def execute()
  if ARGV.empty?
    puts "[!] Usage: http_headers <URL>"
    return
  end

  url = ARGV[0]
  uri = URI(url)
  response = Net::HTTP.get_response(uri)

  print "[*] HTTP Headers for #{url}:"
  response.each_header { |key, value| puts "#{key}: #{value}" }
end

execute()