require 'resolv'

def execute()
  if ARGV.empty?
    puts "[!] Usage: reverse_dns <IP or domain>"
    return
  end

  input = ARGV[0]

  # Проверяем, IP или домен
  begin
    ip = Resolv.getaddress(input)
  rescue Resolv::ResolvError
    print "[-] Invalid domain or IP."
    return
  end

  print "[*] Performing reverse DNS lookup for #{ip}..."

  begin
    hostname = Resolv.getname(ip)
    print "[+] Reverse DNS result: #{hostname}"
  rescue Resolv::ResolvError
    print "[-] Reverse DNS not available for #{ip}"
  end
end

execute()